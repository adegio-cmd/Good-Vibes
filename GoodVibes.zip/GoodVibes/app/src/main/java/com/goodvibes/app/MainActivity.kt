package com.goodvibes.app

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.roundToLong

private data class Preset(val name: String, val intensity: Int, val rate: Int)

class MainActivity : Activity() {

    private companion object {
        val BG = Color.parseColor("#0A0A0F")
        val SURFACE = Color.parseColor("#14141C")
        val SURFACE_HI = Color.parseColor("#1C1C27")
        val STROKE = Color.parseColor("#262634")
        val TRACK = Color.parseColor("#2C2C3C")
        val TEXT = Color.parseColor("#F2F2F7")
        val MUTED = Color.parseColor("#8B8B9E")
        val ACCENT = Color.parseColor("#A78BFA")
        val ACCENT_LIGHT = Color.parseColor("#C4B5FD")
        val ACCENT_DEEP = Color.parseColor("#7C5CFA")

        const val MAX_RATE = 20 // pulses per second; 0 = steady buzz
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private lateinit var vibrator: Vibrator
    private var hasVibrator = false
    private var hasAmplitude = false

    private var running = false
    private var intensity = 60 // 1..100 (%)
    private var rate = 4       // 0..MAX_RATE

    private val handler = Handler(Looper.getMainLooper())
    private val applyRunnable = Runnable { if (running) applyEffect() }
    private var pulseAnim: ValueAnimator? = null

    private lateinit var ring: View
    private lateinit var button: TextView
    private lateinit var status: TextView
    private lateinit var intensityValue: TextView
    private lateinit var rateValue: TextView
    private lateinit var intensityBar: SeekBar
    private lateinit var rateBar: SeekBar

    private val presets = listOf(
        Preset("Gentle", 25, 2),
        Preset("Steady", 55, 0),
        Preset("Pulse", 75, 6),
        Preset("Rapid", 100, 16)
    )

    private val vibrationAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    // ---------------------------------------------------------------- lifecycle

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        hasVibrator = vibrator.hasVibrator()
        hasAmplitude = hasVibrator && vibrator.hasAmplitudeControl()

        setContentView(buildUi())
        setIntensity(intensity)
        setRate(rate)
        refreshButton()
    }

    override fun onStop() {
        super.onStop()
        // Never leave a repeating vibration running once the app is out of sight.
        if (running) stopVibration()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (hasVibrator) vibrator.cancel()
    }

    // ---------------------------------------------------------------- vibration

    private fun toggle() {
        if (!hasVibrator) {
            Toast.makeText(this, "No vibration motor found on this device", Toast.LENGTH_SHORT).show()
            return
        }
        if (running) stopVibration() else startVibration()
    }

    private fun startVibration() {
        running = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        applyEffect()
        startPulseAnim()
        refreshButton()
    }

    private fun stopVibration() {
        running = false
        handler.removeCallbacks(applyRunnable)
        vibrator.cancel()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        stopPulseAnim()
        refreshButton()
    }

    /** Re-issue the effect shortly after a slider moves, so dragging stays smooth. */
    private fun scheduleApply() {
        if (!running) return
        handler.removeCallbacks(applyRunnable)
        handler.postDelayed(applyRunnable, 40)
    }

    @Suppress("DEPRECATION")
    private fun applyEffect() {
        try {
            vibrator.vibrate(buildEffect(), vibrationAttrs)
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't vibrate: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildEffect(): VibrationEffect {
        val level = intensity / 100f
        val amplitude = max(1, (level * 255f).roundToInt())
        return if (rate == 0) steadyEffect(level, amplitude) else pulsedEffect(level, amplitude)
    }

    /** Continuous buzz. Without amplitude control, strength is faked with fast on/off duty cycling. */
    private fun steadyEffect(level: Float, amplitude: Int): VibrationEffect {
        if (hasAmplitude) {
            return VibrationEffect.createWaveform(longArrayOf(1000), intArrayOf(amplitude), 0)
        }
        val period = 60L
        val on = (period * level).toLong().coerceIn(8L, period)
        val off = period - on
        if (off < 4L) return VibrationEffect.createWaveform(longArrayOf(0, 1000), 0)
        return VibrationEffect.createWaveform(longArrayOf(off, on), 0) // timings start with "off"
    }

    /** Repeating pulses: [rate] pulses per second. */
    private fun pulsedEffect(level: Float, amplitude: Int): VibrationEffect {
        val period = (1000f / rate).roundToLong()
        if (hasAmplitude) {
            val on = max(10L, period / 2)
            val off = max(5L, period - on)
            return VibrationEffect.createWaveform(longArrayOf(on, off), intArrayOf(amplitude, 0), 0)
        }
        val on = (period * level).toLong().coerceIn(10L, period - 5L)
        val off = period - on
        return VibrationEffect.createWaveform(longArrayOf(off, on), 0) // timings start with "off"
    }

    // ---------------------------------------------------------------- state -> UI

    private fun setIntensity(value: Int) {
        intensity = value.coerceIn(1, 100)
        intensityBar.progress = intensity - 1
        intensityValue.text = "$intensity%"
        refreshStatus()
        scheduleApply()
    }

    private fun setRate(value: Int) {
        rate = value.coerceIn(0, MAX_RATE)
        rateBar.progress = rate
        rateValue.text = rateLabel()
        refreshStatus()
        scheduleApply()
        if (running) startPulseAnim()
    }

    private fun rateLabel(): String = when (rate) {
        0 -> "Steady"
        1 -> "1 pulse/s"
        else -> "$rate pulses/s"
    }

    private fun refreshStatus() {
        status.text = when {
            !hasVibrator -> "No vibration motor found"
            running -> "Vibrating  ·  $intensity%  ·  ${rateLabel()}"
            else -> "Tap to start"
        }
    }

    private fun refreshButton() {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (running) {
                setColor(SURFACE_HI)
                setStroke(dp(3), ACCENT)
            } else {
                orientation = GradientDrawable.Orientation.TL_BR
                setColors(intArrayOf(ACCENT_LIGHT, ACCENT_DEEP))
            }
        }
        button.background = bg
        button.text = if (running) "STOP" else "START"
        button.setTextColor(if (running) ACCENT else BG)
        refreshStatus()
    }

    private fun startPulseAnim() {
        pulseAnim?.cancel()
        val duration = if (rate == 0) 1400L else (1000f / rate).toLong().coerceIn(250L, 1000L)
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val t = anim.animatedValue as Float
                val grow = 0.15f + 0.30f * intensity / 100f
                val s = 1f + grow * t
                ring.scaleX = s
                ring.scaleY = s
                ring.alpha = 0.6f * (1f - t)
            }
            start()
        }
    }

    private fun stopPulseAnim() {
        pulseAnim?.cancel()
        pulseAnim = null
        ring.alpha = 0f
        ring.scaleX = 1f
        ring.scaleY = 1f
    }

    // ---------------------------------------------------------------- UI building

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(28))
        }
        scroll.addView(root, ViewGroup.LayoutParams(MATCH, WRAP))

        // Header
        root.addView(label("Good Vibes", 30f, TEXT).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            letterSpacing = 0.03f
        })
        root.addView(
            label("Tune your phone's buzz", 14f, MUTED),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) }
        )

        // Big start/stop button with a pulsing ring behind it
        ring = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), ACCENT)
            }
            alpha = 0f
        }
        button = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.18f
            setOnClickListener { toggle() }
        }
        val stack = FrameLayout(this)
        stack.addView(ring, FrameLayout.LayoutParams(dp(176), dp(176), Gravity.CENTER))
        stack.addView(button, FrameLayout.LayoutParams(dp(176), dp(176), Gravity.CENTER))
        root.addView(stack, LinearLayout.LayoutParams(dp(260), dp(260)).apply {
            topMargin = dp(28)
            gravity = Gravity.CENTER_HORIZONTAL
        })

        status = label("", 14f, MUTED)
        root.addView(status, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(4)
            bottomMargin = dp(28)
        })

        // Sliders
        intensityValue = label("", 15f, ACCENT)
        intensityBar = styledBar(99, object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) setIntensity(progress + 1)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        root.addView(
            sliderCard("Intensity", intensityValue, intensityBar),
            LinearLayout.LayoutParams(MATCH, WRAP)
        )

        rateValue = label("", 15f, ACCENT)
        rateBar = styledBar(MAX_RATE, object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) setRate(progress)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        root.addView(
            sliderCard("Frequency", rateValue, rateBar),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
        )

        // Presets
        root.addView(presetRow(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        // Footnote
        val note = when {
            !hasVibrator -> "This device doesn't seem to have a vibration motor."
            !hasAmplitude -> "Your phone can't change vibration strength directly, so intensity is " +
                "simulated by pulsing. Frequency sets how fast the pulses repeat."
            else -> "Phone motors run at a fixed speed, so frequency sets how fast the pulses repeat."
        }
        root.addView(
            label(note, 12f, MUTED).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(20) }
        )

        return scroll
    }

    private fun sliderCard(title: String, value: TextView, bar: SeekBar): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(SURFACE, 20, STROKE)
            setPadding(dp(20), dp(18), dp(20), dp(14))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(
            label(title, 15f, TEXT).apply {
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        header.addView(value, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        return card
    }

    private fun presetRow(): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEachIndexed { i, preset ->
            val chip = label(preset.name, 14f, TEXT).apply {
                gravity = Gravity.CENTER
                background = roundRect(SURFACE, 14, STROKE)
                setPadding(0, dp(12), 0, dp(12))
                setOnClickListener {
                    setIntensity(preset.intensity)
                    setRate(preset.rate)
                }
            }
            row.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
        return row
    }

    private fun styledBar(maxValue: Int, listener: SeekBar.OnSeekBarChangeListener): SeekBar =
        SeekBar(this).apply {
            this.max = maxValue
            progressTintList = ColorStateList.valueOf(ACCENT)
            progressBackgroundTintList = ColorStateList.valueOf(TRACK)
            thumbTintList = ColorStateList.valueOf(ACCENT_LIGHT)
            setOnSeekBarChangeListener(listener)
        }

    private fun label(s: String, sp: Float, color: Int): TextView = TextView(this).apply {
        text = s
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    }

    private fun roundRect(fill: Int, radiusDp: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            setStroke(dp(1), strokeColor)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
