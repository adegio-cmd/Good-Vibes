# Good Vibes

A sleek, dark Android app that drives your phone's vibration motor with adjustable **intensity** and **frequency**.

- Big START / STOP button with a pulsing ring
- Intensity slider (1-100%)
- Frequency slider (Steady, or 1-20 pulses per second)
- Quick presets: Gentle, Steady, Pulse, Rapid
- Changes apply live while it's vibrating
- Vibration stops automatically if you leave the app

Requires Android 8.0+ (API 26). No dependencies beyond the Android framework.

## Get the APK

**Option A - GitHub (no installs):**
1. Create a new GitHub repository and upload this whole folder (keep the `.github` folder).
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. When it finishes, download the `good-vibes-apk` artifact, unzip it, and open `app-debug.apk` on your phone.

**Option B - Android Studio:**
1. Open this folder in Android Studio and let Gradle sync.
2. **Build > Build APK(s)**, or run `./gradlew assembleDebug`.
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

Installing: allow "Install unknown apps" for your browser/file manager when prompted.

## Notes

- Phone vibration motors run at one fixed speed, so "frequency" here means how fast the pulses repeat.
- Intensity uses true amplitude control where the phone supports it. Phones without it get simulated intensity (rapid pulsing).
- The app vibrates with alarm usage so it still works when the phone is on silent.
